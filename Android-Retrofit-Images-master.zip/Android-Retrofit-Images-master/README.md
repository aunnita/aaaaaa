# Android-Retrofit-Images
In this sample Android Project,we use Retrofit and Picasso library for loading image from the server in listview.

This is an example project and completely free to use.The tutorial for this will be available on :

http://themakeinfo.com/2015/04/android-retrofit-images-tutorial/
